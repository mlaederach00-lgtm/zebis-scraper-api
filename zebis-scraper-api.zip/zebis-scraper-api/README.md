# 🧠 Zebis Unterrichtsmaterial Scraper API

Diese API durchsucht **zebis.ch** live nach Unterrichtsmaterialien nach **beliebigen Suchbegriffen**, gefiltert nach **Klasse** und **Fachbereich**.

---

## 📡 Endpunkt

